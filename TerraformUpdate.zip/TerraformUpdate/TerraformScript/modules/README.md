# Introduction 
This folder has all of the Terraform modules for deoploying SPM.


# How to execute this script

go to the main terraform folder and run following commands

1) terraform init
2) Optional: terraform plan 
3) terraform apply -target=module.storage-account

# Note: Here -target=module.storage-account is the terraform module we want to apply

To delete the modules:
# Run: terraform destroy