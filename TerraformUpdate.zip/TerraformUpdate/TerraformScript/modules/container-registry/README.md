# Introduction 
The Terraform module for creating an empty Container Registry for the BDM SPM ARO HFP.