# Introduction 
This module creates the foundational virtual network (VNet) and subnets (SubNets) for a BDM SPM ARO Implementation
