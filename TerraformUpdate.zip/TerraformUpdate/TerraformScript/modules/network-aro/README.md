# Introduction 
Terraform module for creating the Subnets required for an ARO Cluster